<?php
// Replace 'YOUR_BOT_TOKEN' and 'YOUR_CHAT_ID' with your actual bot token and chat ID
$botToken = '6885064915:AAFelplb3aqbKDCZY56-TWYDaqpXfLVobDQ';
$chatId = '1290697237';

// Replace the following variables with the values you want to include in your message
$transaction = $_GET['transaction']; // replace with actual value
$userid = $_GET['userid']; // replace with actual value
$zoneid = $_GET['zoneid']; // replace with actual value
$amount = $_GET['amount']; // replace with actual value
$md5 = $_GET['md5']; // replace with actual value

// Create the message
$message = "News Order: $transaction\nUser ID: $userid\nZone ID: $zoneid\nAmount: $amount\nMD5: $md5";

// Create the URL for the Telegram API
$url = "https://api.telegram.org/bot$botToken/sendMessage?chat_id=$chatId&text=" . urlencode($message);

// Use file_get_contents to send the message
$response = file_get_contents($url);

// You can handle the response as needed
if ($response === false) {
    echo 'Error sending message';
} else {
    echo 'Message sent successfully';
}
?>
